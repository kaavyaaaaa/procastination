# CASE 01 — The Procrastination Mystery

A polished GitHub Pages-ready interactive data-story/game.

### Upload
Upload `index.html`, `style.css`, and `script.js` to a GitHub repository root, then enable GitHub Pages from **Settings → Pages → Deploy from branch → main / root**.

### Important
The Evidence Board uses demo percentages. Replace them with your actual Google Form results before submitting the project.

Sounds are generated with Web Audio, so no audio files are required.
